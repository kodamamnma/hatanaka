/* ─────────────────────────────────────────────
   鹿児島を、語ろう。 — interactions
   ───────────────────────────────────────────── */

/* Theme chip toggle on submit.html */
(function initThemeChips(){
  const chips = document.querySelectorAll('#theme-chips .chip');
  if(!chips.length) return;
  chips.forEach(c => {
    c.addEventListener('click', () => {
      chips.forEach(x => x.classList.remove('solid','red'));
      c.classList.add('solid','red');
    });
  });
})();

/* Submit form: stub handler (replaced when backend connected) */
(function initSubmitForm(){
  const form = document.querySelector('.submit-form');
  if(!form) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('プロトタイプ：実際の送信処理は接続後に動作します');
  });
})();

/* Category-filter chip toggle on articles.html */
(function initCategoryFilters(){
  const chips = document.querySelectorAll('.filters .chip');
  if(!chips.length) return;
  chips.forEach(c => {
    c.addEventListener('click', () => {
      chips.forEach(x => x.classList.remove('solid'));
      c.classList.add('solid');
    });
  });
})();
